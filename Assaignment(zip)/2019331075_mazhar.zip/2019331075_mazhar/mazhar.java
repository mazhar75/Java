
class mazhar{
   public static void main(String [] args){
   stack st=new stack();
   for(int i=1;i<25;i++){
   st.push(i);
   }
   for(int i=1;i<23;i++){
   System.out.println(st.pop());
   }
   }
}