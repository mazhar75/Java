
package p1;
class C{
	
A p=new A();
C(){
	
	
   System.out.println("x="+x);
   //System.out.println("y="+y);
   System.out.println("z="+z);
   System.out.println("q="+q);
   
}

}