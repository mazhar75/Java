

package p1;
public class A{
	
	int x=1;
	private int y=2;
	protected int z=3;
	public int q=4;
public	A(){
   System.out.println("x="+x);
   System.out.println("y="+y);
   System.out.println("z="+z);
   System.out.println("q="+q);
   }

}

