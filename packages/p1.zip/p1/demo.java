
package p1;
public class demo{
public static void main(String[] args){
	
	A a=new A();
	B b=new B();
	C c=new C();
}	

}