
package p1;
class B extends A{
	B(){
   System.out.println("x="+x);
   //System.out.println("y="+y);
   System.out.println("z="+z);
   System.out.println("q="+q);
   }
}   
